﻿How to deploy a WAR file in Tomcat
+ Install Apache Tomcat http://tomcat.apache.org/
+ Move URLRedirector.war to folder %TOMCAT_HOME%/webapps
+ Start Tomcat

Your Proxy link
http://%YOUR_SERVER%/URLRedirector/handler